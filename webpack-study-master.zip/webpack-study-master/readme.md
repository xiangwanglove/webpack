webpack学习
======

## 说明
一切尽在jsliang-webpack遨游.doc，想学习的小伙伴对着练习一遍，对webpack就有初略映像啦！上面还有个人学习文档，可以对着看文档； 然后jsliang在 <a href="https://github.com/LiangJunrong/webpack-study">webpack-MPA-config</a> 上做了jsliang个人的多页面配置，后续会持续优化，觉得可以的小伙伴帮忙给这两个项目点个star，码字不易，谢谢~  

## 运行方式
· 安装依赖包：npm i  
· 进入开发模式：npm run dev  
· 进入生产模式：npm run build  

## 文件夹对应Word章节
· webpack-1 对应 章节2.2+章节2.3  
· webpack-2 对应 章节2.4  
· webpack-3 对应 章节2.5  
· webpack-4 对应 章节2.6  
· webpack-5 对应 章节2.7  
